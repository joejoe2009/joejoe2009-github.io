#! /bin/bash

if [ $# -ne 2 ];then
    exit -1
fi

if [ -e "$2" -a -f "$2" ];then
   sed '/CGDCONT/d' "$2" > "$2.bak"
   mv "$2.bak" "$2"
   
   sed '/ATQ0/a\OK \"AT+CGDCONT=1,\\"IP\\",\\"'"$1"'\\""' "$2" > "$2.bak"
   mv "$2.bak" "$2"
fi
