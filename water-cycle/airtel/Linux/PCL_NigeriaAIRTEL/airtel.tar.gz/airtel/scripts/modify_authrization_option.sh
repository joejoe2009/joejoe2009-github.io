#! /bin/bash

if [ $# -ne 2 ];then
    exit -1
fi

if [ -e "$2" -a -f "$2" ];then
    sed -e '/refuse/d' -e  '/require/d' -e '/-vj/a\refuse-pap' -e '/-vj/a\refuse-chap'  -e '/-vj/a\refuse-mschap' -e '/-vj/a\refuse-mschap-v2'  -e '/-vj/a\refuse-eap'  "$2" > "$2.bak"
    mv "$2.bak" "$2"
   
    sed -e '/'^refuse-"$1"$'/d' "$2" > "$2.bak"
    mv "$2.bak" "$2"
fi
