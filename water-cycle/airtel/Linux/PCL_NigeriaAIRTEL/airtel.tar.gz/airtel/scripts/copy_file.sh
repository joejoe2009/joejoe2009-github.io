#! /bin/bash

if [ $# -eq 2 ];then
    if [ -f $1 ];then
        cp -f $1 $2
    fi
fi
