#! /bin/bash

if [ $# -ne 4 ];then
    echo "need 4 arguments"
    exit -1
fi

touch "$4"
touch /tmp/zttemp

if [ -e "$4" -a -f "$4" ] ; then
    sed -n '/'$2'/p' "$4" > /tmp/zttemp
    RES=`sed -n '/'$3'/p' /tmp/zttemp`

    if [ -z "$RES" ]; then
        echo "$1" >> "$4"
    fi
fi

