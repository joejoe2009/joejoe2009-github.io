#! /bin/bash

if [ $# -ne 1 ];then
    exit -1
fi
if [ -e "$1" -a -f "$1" ];then
   sed '/CGDCONT/d' "$1" > "$1.bak"
   mv "$1.bak" "$1"
fi
