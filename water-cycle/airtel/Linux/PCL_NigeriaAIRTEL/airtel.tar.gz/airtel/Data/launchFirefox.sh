#! /bin/bash

if [ -z $DBUS_SESSION_BUS_ADDRESS ];then
    DBUS_SESSION_BUS_ADDRESS_LONG=$(grep ^DBUS_SESSION_BUS_ADDRESS $HOME/.dbus/session-bus/$(dbus-uuidgen --get)-$(echo $DISPLAY | sed -e 's/\([^:]*:\)//g' -e 's/\..*$//g')) 
    DBUS_SESSION_BUS_ADDRESS=${DBUS_SESSION_BUS_ADDRESS_LONG#*DBUS_SESSION_BUS_ADDRESS=}
fi

firefox $@
